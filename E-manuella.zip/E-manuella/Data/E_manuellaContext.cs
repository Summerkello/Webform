﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using E_manuella.Model;

namespace E_manuella.Data
{
    public class E_manuellaContext : DbContext
    {
        public E_manuellaContext (DbContextOptions<E_manuellaContext> options)
            : base(options)
        {
        }

        public DbSet<E_manuella.Model.User> User { get; set; } = default!;
    }
}
