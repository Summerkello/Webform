﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using E_MANUAL_POS.Model;

namespace E_MANUAL_POS.Data
{
    public class E_MANUAL_POSContext : DbContext
    {
        public E_MANUAL_POSContext (DbContextOptions<E_MANUAL_POSContext> options)
            : base(options)
        {
        }

        public DbSet<E_MANUAL_POS.Model.Employee> Employee { get; set; } = default!;
        public DbSet<E_MANUAL_POS.Model.Book> Book { get; set; } = default!;
    }
}
