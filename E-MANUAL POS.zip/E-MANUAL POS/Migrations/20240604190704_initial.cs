﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace E_MANUAL_POS.Migrations
{
    /// <inheritdoc />
    public partial class initial : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Employee",
                columns: table => new
                {
                    ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    employee_Fname = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    employee_Lname = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    employee_email = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    employee_phoneNo = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    employee_role = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    employee_password = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Employee", x => x.ID);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Employee");
        }
    }
}
