﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace E_MANUAL_POS.Migrations
{
    /// <inheritdoc />
    public partial class booker : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Book",
                columns: table => new
                {
                    BookId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    supplier_id = table.Column<int>(type: "int", nullable: false),
                    book_title = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    book_type = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    book_author = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    book_edition = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    book_publisher = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    book_price = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Book", x => x.BookId);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Book");
        }
    }
}
