﻿using Microsoft.EntityFrameworkCore;
using System.Runtime.InteropServices;

namespace E_MANUAL_POS.Model
{
	public class Book
	{
		
		public int BookId { get; set; }



		//public DbSet<ISBN> ISBN { get; set; }

		//protected override void OnModelCreating(ModelBuilder modelBuilder)
		//{
		//	modelBuilder.Entity<ISBN>().HasKey(x => x.ISBN);
		//	base.OnModelCreating(modelBuilder);
		//}

		public int supplier_id { get; set; }

		public string book_title { get; set; }

		public string book_type { get; set; }
		public string book_author { get; set; }
		public string book_edition { get; set; }
		public string book_publisher { get; set; }
		public string book_price { get; set; }
	}
}
