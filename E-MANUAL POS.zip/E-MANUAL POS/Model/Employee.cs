﻿namespace E_MANUAL_POS.Model
{
	public class Employee
	{
		public int ID { get; set; }
		public string employee_Fname { get; set; }
		public string employee_Lname { get; set; }
		public string employee_email { get; set; }
		public string employee_phoneNo { get; set; }
		public string employee_role { get; set; }
		public string employee_password { get; set; }
	}
}
