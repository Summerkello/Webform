﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using E_MANUAL_POS.Data;
using E_MANUAL_POS.Model;

namespace E_MANUAL_POS.Pages.Books
{
    public class DetailsModel : PageModel
    {
        private readonly E_MANUAL_POS.Data.E_MANUAL_POSContext _context;

        public DetailsModel(E_MANUAL_POS.Data.E_MANUAL_POSContext context)
        {
            _context = context;
        }

        public Book Book { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var book = await _context.Book.FirstOrDefaultAsync(m => m.BookId == id);
            if (book == null)
            {
                return NotFound();
            }
            else
            {
                Book = book;
            }
            return Page();
        }
    }
}
