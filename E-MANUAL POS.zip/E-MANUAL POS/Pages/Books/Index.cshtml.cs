﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using E_MANUAL_POS.Data;
using E_MANUAL_POS.Model;

namespace E_MANUAL_POS.Pages.Books
{
    public class IndexModel : PageModel
    {
        private readonly E_MANUAL_POS.Data.E_MANUAL_POSContext _context;

        public IndexModel(E_MANUAL_POS.Data.E_MANUAL_POSContext context)
        {
            _context = context;
        }

        public IList<Book> Book { get;set; } = default!;

        public async Task OnGetAsync()
        {
            Book = await _context.Book.ToListAsync();
        }
    }
}
