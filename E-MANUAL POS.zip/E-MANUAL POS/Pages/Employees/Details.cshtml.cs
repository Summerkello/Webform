﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using E_MANUAL_POS.Data;
using E_MANUAL_POS.Model;

namespace E_MANUAL_POS.Pages.Employees
{
    public class DetailsModel : PageModel
    {
        private readonly E_MANUAL_POS.Data.E_MANUAL_POSContext _context;

        public DetailsModel(E_MANUAL_POS.Data.E_MANUAL_POSContext context)
        {
            _context = context;
        }

        public Employee Employee { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var employee = await _context.Employee.FirstOrDefaultAsync(m => m.ID == id);
            if (employee == null)
            {
                return NotFound();
            }
            else
            {
                Employee = employee;
            }
            return Page();
        }
    }
}
